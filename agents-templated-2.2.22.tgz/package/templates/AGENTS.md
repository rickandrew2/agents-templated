# AGENTS Instructions

> Primary policy: [`CLAUDE.md`](CLAUDE.md).
> This file is a compatibility pointer. All policy lives in CLAUDE.md.
> If this file and CLAUDE.md conflict, CLAUDE.md wins.
